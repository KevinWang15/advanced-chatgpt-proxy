module.exports = {
  "console": {
    "adminPassword": "admin"
  },
  "accounts": []
};